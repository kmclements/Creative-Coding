var headX = 200;
var headY = 200;
var headDirection = 1;

var leyeX = 170;
var leyeY = 190;
var leyeDirection = 1;

var lipsX = 200;
var lipsY = 245;
var lipsDirection = 1;

var bunX = 200;
var bunY = 110;
var bunDirection = 1;

var noseX = 200;
var noseY = 245;
var noseDirection = 1;


var size = 22;
var count = 5;
var sizeDirection = 2;


function setup() {
  createCanvas(400, 400);
}

function draw() {
//head
  background(201, 219, 186);
 let c = color(245, 205, 167);
fill(c);
noStroke();
  circle(headX, headY,150);
  headX+=headDirection;
    if(headX >=300 || headX <= 100)
    {
        headDirection *= -1;
    }

//nose
  strokeWeight(1);
stroke(51);
  triangle( noseX, noseY, 200, 207, 210, 222)
  
     noseY+=noseDirection;
  if(noseY >=260 || noseY <= 230)
    {
        noseDirection *= -1;
    }
 
//white eyes  
  strokeWeight(1);
stroke(51);
  let w = color( 255, 255, 255);
fill(w);
  ellipse( 170, 190, 30, 18)
  ellipse( 230, 190, 30, 18)
  
//hair + eyebrows  
  let z = color(67, 41, 31);
fill(z);
strokeWeight(1)
  stroke(67, 41, 31)
  rect(155,170, 30, 5)
  rect(215,170, 30, 5)
  bezier( 135, 160, 155, 100, 230, 100, 265, 160)
  ellipse(bunX, bunY, 50, 60)
   
  bunX+=bunDirection;
  if(bunX >=180 || bunX <= 160)
  if(bunY >=100 || bunY <= 130)
    {
        bunDirection *= -1;
    }
  
//eye color
  let g= color(110, 136, 152)
  fill(g)
  noStroke();
  circle(170, 190, 16)
  circle(230, 190, 16)
  
  
//pupils
  let m=color(40, 40, 43)
  fill(m)
  circle(leyeX, leyeY, 8)
  circle(230, 190, 8)
 
  leyeX+=leyeDirection;
  if(leyeX >=180 || leyeX <= 160)
    {
        leyeDirection *= -1;
    }
 
  
//lips
  let p=color(193, 102, 107)
  fill(p)
  strokeWeight(1);
stroke(193, 71, 107);
  line(185, 245, 215, 245)
  ellipse(lipsX, lipsY, 30, 12)
  
    lipsY+=lipsDirection;
  if(lipsY >=260 || lipsY <= 230)
    {
        lipsDirection *= -1;
    }
  
fill(193);
    textSize(size);
    size+= sizeDirection;
    count++;
    if(count > 10)
    {
        sizeDirection *=-1;
        count = 5;
    }
    text("krissy clements",125,50 );


}