var x = 0;
var y = 0;
var gap = 10;
var deg = 0;
var color2 = 'white';

function setup() {
	createCanvas(600,600);
	background(136, 149, 141);
	frameRate(90);
	
}

function mousePressed() { //changes to purple when mouse is clicked
	color2 = '#17255a'; }


function mouseReleased() { //goes back to white when mouse is let go
	color2 = '#white'; }

function draw() {
	spin();
	maze();
	grid();
}


function maze() { // background lines
	
	stroke(color2);
	strokeWeight(3);
	if (random(5) <0.5) { // random line pattern
	line(x, y, x + gap, y + gap);
	} else {
	line(x, y + gap, x + gap, y);
	}
	
	x = x+ 10; //This allows the lines to go across the canvas.
	if (x > width) {
	x = 0;
	y = y + gap;
	}
	
}

function grid() { 
	
	for ( var i = 0; i < windowWidth; i += 45 ) {
	for ( var j = 0; j < windowHeight; j += 45 ) {
	noStroke();
	fill(color2);
	rotate(PI);
	ellipse (i, j, 8, 8);
					
		}
	}
}
function spin() { //spinning circle
	push();
	scale(1);
	translate(width/2,height/2);
	rotate(radians(deg));
	deg++;
	fill(color2);
	rect(0,0,15,200);
	pop();
} 