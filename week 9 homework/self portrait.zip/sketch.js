function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(201, 219, 186);
 let c = color(245, 205, 167);
fill(c);
noStroke();
  circle(200,200,150);

  strokeWeight(1);
stroke(51);
  triangle( 190, 222, 200, 207, 210, 222)
 
  strokeWeight(1);
stroke(51);
  let w = color( 255, 255, 255);
fill(w);
  ellipse( 170, 190, 30, 18)
  ellipse( 230, 190, 30, 18)
  
  let b = color(67, 41, 31);
fill(b);
strokeWeight(1)
  stroke(67, 41, 31)
  rect(155,170, 30, 5)
  rect(215,170, 30, 5)
  ellipse(200, 110, 50, 60)
  bezier( 135, 160, 155, 100, 230, 100, 265, 160)
  
  let g= color(110, 136, 152)
  fill(g)
  noStroke();
  circle(170, 190, 16)
  circle(230, 190, 16)
  
  let l=color(40, 40, 43)
  fill(l)
  circle(170, 190, 8)
  circle(230, 190, 8)
  
  let p=color(193, 102, 107)
  fill(p)
  strokeWeight(1);
stroke(193, 71, 107);
  line(185, 245, 215, 245)
  ellipse(200, 245, 30, 12)
  

  text('krissy clements', 85, 50);
  textSize(35)
}